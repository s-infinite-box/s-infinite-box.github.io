switch_screen() (
  # 用法：switch_screen [toggle|linux|windows|status] [连接器]
  # 本机输入对应：Linux 为 DP-1（15），Windows 为 HDMI-1（0x11），移植时重新确认。
  set -o pipefail
  local action="${1:-toggle}" output="${2:-${MONITOR_CONNECTOR:-DP-2}}"
  local monitor ddc_bus screen settings windows enabled
  local -a linux_on
  case "$action" in toggle|linux|windows|status) ;; *) echo 'Usage: switch_screen [toggle|linux|windows|status] [connector]' >&2; return 2;; esac
  [[ "$output" =~ ^[A-Za-z0-9-]+$ ]] || return 2
  exec 9>"${XDG_RUNTIME_DIR:-/run/user/$UID}/switch-screen-$output.lock" || return 1
  flock -n 9 || { echo 'Another screen switch is running.' >&2; return 1; }
  monitor=$(python3 - "$output" <<'PY'
import pathlib, sys
ports = [p for p in pathlib.Path('/sys/class/drm').glob('card*-' + sys.argv[1])
         if (p / 'status').read_text().strip() == 'connected']
if len(ports) != 1: sys.exit('Expected one connected output: ' + sys.argv[1])
e = (ports[0] / 'edid').read_bytes()
if len(e) < 128 or e[:8] != bytes.fromhex('00ffffffffffff00') or sum(e[:128]) % 256:
    sys.exit('Invalid monitor EDID')
m = int.from_bytes(e[8:10], 'big')
bus = next(ports[0].glob('i2c-*'), (ports[0] / 'ddc').resolve()).name.removeprefix('i2c-')
if not bus.isdigit(): sys.exit('No DDC bus for ' + sys.argv[1])
print(''.join(chr(64 + ((m >> n) & 31)) for n in (10, 5, 0)) + format(int.from_bytes(e[10:12], 'little'), '04X'), bus)
PY
  ) || return 1
  read -r monitor ddc_bus <<<"$monitor"
  screen=$(timeout 8 kscreen-doctor -j | jq -ce --arg name "$output" '.outputs[] | select(.name==$name and .connected)') || return 1
  if [[ "$action" != status ]]; then
    settings=$(jq -er --arg name "$output" '
      .currentModeId as $id | . as $output | .modes[] | select(.id==$id) |
      "output.\($name).enable", "output.\($name).mode.\(.id)",
      "output.\($name).scale.\($output.scale)", "output.\($name).position.\($output.pos.x),\($output.pos.y)"
      ' <<<"$screen") || { echo 'Enable this screen in KDE once to choose its display settings.' >&2; return 1; }
    mapfile -t linux_on <<<"$settings"
    timeout 8 kscreen-doctor "${linux_on[@]}" || return 1
    timeout 8 kscreen-doctor -j | jq -e --arg name "$output" '.outputs[] | select(.name==$name) | .enabled' >/dev/null || return 1
  fi
  windows=$(timeout 70 ssh -o BatchMode=yes -o ConnectTimeout=5 -o ServerAliveInterval=5 -o ServerAliveCountMax=2 \
    -p "${MONITOR_SSH_PORT:-22}" "${MONITOR_SSH_HOST:-desktop-user@192.0.2.20}" \
    powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass \
    -File 'C:\Tools\switch_screen.ps1' -MonitorId "$monitor" -Action "$action" -InputSource 15) || return 1
  jq -e '(.active | type)=="boolean"' >/dev/null <<<"$windows" || return 1
  enabled=$(jq -r .active <<<"$windows")
  if [[ "$action" != status && "$enabled" == true ]]; then
    timeout 8 ddcutil --bus "$ddc_bus" --skip-ddc-checks setvcp 60 0x11 --noverify || return 1
    timeout 8 kscreen-doctor "output.$output.disable" || return 1
  fi
  screen=$(timeout 8 kscreen-doctor -j | jq -ce --arg name "$output" '.outputs[] | select(.name==$name) | {name,enabled,scale,pos,mode:(.currentModeId as $id | [.modes[] | select(.id==$id) | .name][0])}') || return 1
  if [[ "$action" != status && $(jq -r .enabled <<<"$screen") == "$enabled" ]]; then
    echo 'Linux and Windows output states do not match the requested switch.' >&2; return 1
  fi
  jq -n --argjson linux "$screen" --argjson windows "$windows" '{linux:$linux,windows:$windows}'
)
