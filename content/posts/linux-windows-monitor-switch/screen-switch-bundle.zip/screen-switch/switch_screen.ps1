param(
    [ValidateSet('toggle', 'linux', 'windows', 'status')][string]$Action = 'toggle',
    [Parameter(Mandatory = $true)][ValidatePattern('^[A-Z]{3}[0-9A-F]{4}$')][string]$MonitorId,
    # 禁用 Windows 输出前选择 DDC/CI 输入源（VCP 0x60）；-1 表示不改变输入。
    [ValidateRange(-1, 255)][int]$InputSource = -1,
    [switch]$Worker,
    [string]$JobDirectory
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$tool = 'C:\Tools\MultiMonitorTool.exe'

if (-not $Worker) {
    $taskName = 'SwitchScreen-' + [guid]::NewGuid().ToString('N')
    $job = Join-Path $env:TEMP $taskName
    $resultFile = Join-Path $job 'result.json'
    $folder = $running = $null
    $registered = $false
    try {
        $user = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        if ((Get-CimInstance Win32_ComputerSystem).UserName -ne $user) {
            throw 'SSH must use the account signed into the Windows desktop.'
        }
        if (-not (Test-Path -LiteralPath $tool -PathType Leaf)) { throw "Missing $tool" }
        New-Item -ItemType Directory -Path $job | Out-Null
        $scheduler = New-Object -ComObject Schedule.Service
        $scheduler.Connect()
        $folder = $scheduler.GetFolder('\')
        $definition = $scheduler.NewTask(0)
        $definition.Principal.UserId = $user
        $definition.Principal.LogonType = 3 # 使用交互令牌，不保存密码。
        $definition.Settings.ExecutionTimeLimit = 'PT60S'
        $definition.Settings.DisallowStartIfOnBatteries = $false
        $definition.Settings.StopIfGoingOnBatteries = $false
        $definition.Settings.Hidden = $true
        $launch = $definition.Actions.Create(0)
        $launch.Path = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
        $launch.Arguments = '-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "{0}" -Action {1} -MonitorId {2} -InputSource {3} -Worker -JobDirectory "{4}"' -f $PSCommandPath, $Action, $MonitorId, $InputSource, $job
        $task = $folder.RegisterTaskDefinition($taskName, $definition, 2, $user, $null, 3)
        $registered = $true
        $running = $task.Run($null)
        $deadline = [DateTime]::UtcNow.AddSeconds(60)
        while (-not (Test-Path -LiteralPath $resultFile)) {
            if ([DateTime]::UtcNow -ge $deadline) { throw 'Desktop screen operation timed out.' }
            Start-Sleep -Milliseconds 150
        }
        $result = Get-Content -LiteralPath $resultFile -Raw | ConvertFrom-Json
        if (-not $result.ok) { throw $result.error }
        $result.monitor | ConvertTo-Json -Compress
    }
    catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }
    finally {
        if ($running -and -not (Test-Path -LiteralPath $resultFile)) { try { $running.Stop() } catch {} }
        if ($registered) { try { $folder.DeleteTask($taskName, 0) } catch { [Console]::Error.WriteLine($_.Exception.Message) } }
        if (Test-Path -LiteralPath $job) { Remove-Item -LiteralPath $job -Recurse -Force }
    }
    exit 0
}

function Invoke-Mmt([string]$Arguments) {
    $start = New-Object Diagnostics.ProcessStartInfo
    $start.FileName = $tool; $start.Arguments = $Arguments
    $start.UseShellExecute = $false; $start.CreateNoWindow = $true
    $process = [Diagnostics.Process]::Start($start)
    if (-not $process.WaitForExit(10000)) { $process.Kill(); throw 'MultiMonitorTool timed out.' }
    $process.Refresh()
    if ($process.ExitCode -ne 0) { throw "MultiMonitorTool failed: $($process.ExitCode)" }
}
function Get-Screen([switch]$Optional) {
    $csv = Join-Path $JobDirectory 'monitors.csv'
    if (Test-Path -LiteralPath $csv) { Remove-Item -LiteralPath $csv -Force }
    Invoke-Mmt ('/scomma "{0}"' -f $csv)
    $script:rows = @(Import-Csv -LiteralPath $csv)
    $matches = @($script:rows | Where-Object { $_.'Short Monitor ID' -eq $MonitorId -and $_.Disconnected -ne 'Yes' })
    if ($Optional -and $matches.Count -eq 0) { return $null }
    if ($matches.Count -ne 1) { throw "Expected one display with ID $MonitorId, found $($matches.Count)." }
    if ($matches[0].Active -notin @('Yes', 'No')) { throw 'Unrecognized monitor Active value.' }
    return $matches[0]
}
function Set-InputSource([string]$DeviceName, [int]$Value) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class SwitchScreenDdc {
    struct RECT { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    struct MONITORINFOEX {
        public int cbSize; public RECT rcMonitor; public RECT rcWork; public uint dwFlags;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string szDevice;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    struct PHYSICAL_MONITOR {
        public IntPtr hPhysicalMonitor;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string szPhysicalMonitorDescription;
    }
    delegate bool MonitorEnumProc(IntPtr hMonitor, IntPtr hdc, IntPtr rect, IntPtr data);
    [DllImport("user32.dll")] static extern bool EnumDisplayMonitors(IntPtr hdc, IntPtr clip, MonitorEnumProc proc, IntPtr data);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern bool GetMonitorInfo(IntPtr hMonitor, ref MONITORINFOEX info);
    [DllImport("dxva2.dll")] static extern bool GetNumberOfPhysicalMonitorsFromHMONITOR(IntPtr hMonitor, out uint count);
    [DllImport("dxva2.dll")] static extern bool GetPhysicalMonitorsFromHMONITOR(IntPtr hMonitor, uint count, [Out] PHYSICAL_MONITOR[] monitors);
    [DllImport("dxva2.dll")] static extern bool SetVCPFeature(IntPtr hMonitor, byte code, uint value);
    [DllImport("dxva2.dll")] static extern bool DestroyPhysicalMonitors(uint count, PHYSICAL_MONITOR[] monitors);
    public static void SetInput(string device, uint value) {
        IntPtr found = IntPtr.Zero;
        EnumDisplayMonitors(IntPtr.Zero, IntPtr.Zero, (m, hdc, rect, data) => {
            var info = new MONITORINFOEX();
            info.cbSize = Marshal.SizeOf(info);
            if (GetMonitorInfo(m, ref info) && info.szDevice == device) { found = m; return false; }
            return true;
        }, IntPtr.Zero);
        if (found == IntPtr.Zero) throw new Exception("No active monitor handle for " + device);
        uint count;
        if (!GetNumberOfPhysicalMonitorsFromHMONITOR(found, out count) || count == 0) throw new Exception("No physical monitor for " + device);
        var monitors = new PHYSICAL_MONITOR[count];
        if (!GetPhysicalMonitorsFromHMONITOR(found, count, monitors)) throw new Exception("Cannot open physical monitor for " + device);
        try {
            if (!SetVCPFeature(monitors[0].hPhysicalMonitor, 0x60, value)) throw new Exception("DDC/CI input switch failed on " + device);
        } finally { DestroyPhysicalMonitors(count, monitors); }
    }
}
'@
    [SwitchScreenDdc]::SetInput($DeviceName, [uint32]$Value)
}
try {
    if ([Diagnostics.Process]::GetCurrentProcess().SessionId -eq 0) { throw 'Screen worker needs the interactive desktop.' }
    $rollback = $null
    $profile = Join-Path $env:LOCALAPPDATA ('SwitchScreen-' + $MonitorId + '.cfg')
    $screen = Get-Screen -Optional
    $active = $screen -and $screen.Active -eq 'Yes'
    $desired = if ($Action -eq 'toggle') { -not $active } else { $Action -eq 'windows' }
    if ($Action -ne 'status' -and $desired -and -not $screen) {
        # 切换输入可能导致显示器断开，等待 Windows 识别热插拔。
        $deadline = [DateTime]::UtcNow.AddSeconds(20)
        while (-not $screen -and [DateTime]::UtcNow -lt $deadline) {
            Start-Sleep -Milliseconds 500
            $screen = Get-Screen -Optional
        }
        if (-not $screen) { throw "Windows did not detect display $MonitorId; check the GPU cable and monitor input." }
    }
    $active = $screen -and $screen.Active -eq 'Yes'
    if ($Action -ne 'status' -and $screen) {
        if ($active -ne $desired) {
            if (-not $desired -and @($rows | Where-Object { $_.Active -eq 'Yes' }).Count -lt 2) {
                throw 'Refusing to disable the only active Windows display.'
            }
            if ([string]::IsNullOrWhiteSpace($screen.'Monitor ID')) { throw 'Selected display has no device ID.' }
            $operation = if ($desired) { 'enable' } else { 'disable' }
            if ($desired -and (Test-Path -LiteralPath $profile)) {
                Invoke-Mmt ('/LoadConfig "{0}"' -f $profile)
            } else {
                if (-not $desired) {
                    Invoke-Mmt ('/SaveConfig "{0}"' -f $profile)
                    $rollback = $profile
                    if ($screen.Primary -eq 'Yes') {
                        $other = $rows | Where-Object { $_.Active -eq 'Yes' -and $_.'Monitor ID' -ne $screen.'Monitor ID' } | Select-Object -First 1
                        Invoke-Mmt ('/SetPrimary "{0}"' -f $other.'Monitor ID')
                        $screen = Get-Screen
                        if ($screen.Primary -eq 'Yes') { throw 'Windows did not transfer the primary display.' }
                    }
                    if ($InputSource -ge 0) { Set-InputSource $screen.Name $InputSource }
                }
                Invoke-Mmt ('/{0} "{1}"' -f $operation, $screen.'Monitor ID')
            }
            $deadline = [DateTime]::UtcNow.AddSeconds(20)
            do {
                try { $current = Get-Screen -Optional }
                catch {
                    if ([DateTime]::UtcNow -ge $deadline) { throw }
                    Start-Sleep -Milliseconds 250; continue
                }
                if ($current) { $screen = $current }
                $active = $current -and $current.Active -eq 'Yes'
                if ($active -eq $desired) { break }
                Start-Sleep -Milliseconds 250
            } while ([DateTime]::UtcNow -lt $deadline)
            if ($active -ne $desired) { throw "Display did not become $operation." }
        }
    }
    $result = @{ ok = $true; monitor = @{
        active = $active; id = $MonitorId; name = $screen.Name
        resolution = $screen.Resolution; frequency = $screen.Frequency
        position = $screen.'Left-Top'; primary = ($screen.Primary -eq 'Yes')
    } }
}
catch {
    $errorMessage = $_.Exception.Message
    if ($rollback) { try { Invoke-Mmt ('/LoadConfig "{0}"' -f $rollback) } catch { $errorMessage += '; rollback: ' + $_.Exception.Message } }
    $result = @{ ok = $false; error = $errorMessage }
}
$resultFile = Join-Path $JobDirectory 'result.json'
$result | ConvertTo-Json -Compress -Depth 3 | Set-Content -LiteralPath ($resultFile + '.tmp') -Encoding UTF8
Move-Item -LiteralPath ($resultFile + '.tmp') -Destination $resultFile -Force
