# 多机器监控基础配置

这是 2026 年 10 月 11 日从文章示例整理的最小配置，配套文章说明部署步骤。它不包含二进制、凭据、生产数据、K3s 部署、外部通知或原部署完整的进程、Docker、GPU 面板。

- `central/`：VictoriaMetrics、Grafana、数据源和四个基础面板。
- `linux/`：Linux 主机采集配置；默认 `home-linux`，通过 `.env` 调整主机名、站点、写入地址。
- `windows/`：Windows 原生采集配置；将 `192.0.2.1` 替换成虚拟机能访问的宿主机网关，主机标签默认 `win11`。

版本固定为 VictoriaMetrics 1.153.0、Grafana 13.2.3、Telegraf 1.40.1。三个主机标签保持唯一；CPU、内存和磁盘容量字段与基础看板查询匹配。中心数据目录选独立位置，不与现有数据库共用。

中心初始化时生成本机 `.env` 和密码文件。Grafana 密码文件用于首次创建管理员；已有数据库的管理员密码不会因改文件自动更新。

Windows 在管理员 PowerShell 中创建 `C:\ProgramData\Telegraf\logs`，把配置保存为 `C:\ProgramData\Telegraf\telegraf.conf`。先用 `telegraf.exe --config ... --test` 检查采集；`--test` 不向输出端写数据。再执行 `telegraf.exe --config ... service install` 并启动服务。服务账号要能读取配置、写日志并访问采集对象。

本配置包只完成静态结构、语法和资源链接检查，没有在新环境重新部署。文章的历史实测数字对应原完整部署。生产脚本未作修改。
